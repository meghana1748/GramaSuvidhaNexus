This folder contains the extracted APK contents.
Files include AndroidManifest.xml, resources, assets, and compiled DEX files.
To fully recover readable Java/Kotlin source code, use JADX or Android Studio APK Analyzer.
